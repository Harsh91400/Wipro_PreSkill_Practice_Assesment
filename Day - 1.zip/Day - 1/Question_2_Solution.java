package Day_1_Class_Assesment;
import java.util.Scanner;

public class Question_2_Solution {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // TODO: Write your code here
        boolean input1 = scanner.nextBoolean();
        boolean input2 = scanner.nextBoolean();

        System.out.println(input1 && input2);
        System.out.println(input1 || input2);



    }
}